package com.cdac.trainging.lawyer.exception;

public class LawyerResourceNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LawyerResourceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
