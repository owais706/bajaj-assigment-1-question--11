package com.cdac.trainging.lawyer.exception;

public class UserResourceNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserResourceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
