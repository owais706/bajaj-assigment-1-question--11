package com.cdac.trainging.lawyer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LawyerManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LawyerManagementSystemApplication.class, args);
	}

}
