package com.cdac.trainging.lawyer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LawyerManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
