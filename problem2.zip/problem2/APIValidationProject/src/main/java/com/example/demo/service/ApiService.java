package com.example.demo.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.User;

@Service
public class ApiService {

    private final RestTemplate restTemplate;

    @Autowired
    public ApiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<String> createUser(User user) {
        String url = "https://bfhldevapigw.healthrx.co.in/automation-campus/create/user";
        HttpHeaders headers = new HttpHeaders();
        headers.set("roll-number", "240350120015");
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<User> request = new HttpEntity<>(user, headers);
        return restTemplate.postForEntity(url, request, String.class);
    }
}

