package com.example.demo;





import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.model.User;
import com.example.demo.service.ApiService;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class ApiServiceTest {

    @Autowired
    private ApiService apiService;

    @Test
    public void testCreateUserSuccess() {
        User user = new User("Test", "Test", 9999999999L, "test.test@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testDuplicatePhoneNumber() {
        User user = new User("Test", "Test", 9999999999L, "test.test2@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testMissingRollNumber() {
        
        User user = new User("Test", "Test", 9999999998L, "test.test3@test.com");
        
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }
    @Test
    public void testNullUser() {
        ResponseEntity<String> response = apiService.createUser(null);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testEmptyFirstName() {
        User user = new User("", "Test", 9999999997L, "test.emptyfirst@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testEmptyLastName() {
        User user = new User("Test", "", 9999999996L, "test.emptylast@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testInvalidPhoneNumberLength() {
        User user = new User("Test", "Test", 999999L, "test.invalidphone@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testInvalidEmailFormat() {
        User user = new User("Test", "Test", 9999999995L, "test.invalidemail");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testNullEmail() {
        User user = new User("Test", "Test", 9999999994L, null);
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testEmailAlreadyExists() {
        User user1 = new User("Test1", "Test1", 9999999993L, "duplicate.email@test.com");
        User user2 = new User("Test2", "Test2", 9999999992L, "duplicate.email@test.com");

        apiService.createUser(user1);
        ResponseEntity<String> response = apiService.createUser(user2);
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    }

    @Test
    public void testInvalidPhoneNumberCharacters() {
        User user = new User("Test", "Test", Long.parseLong("invalidphone"), "test.invalidchar@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testFirstNameExceedsMaxLength() {
        User user = new User("TestTestTestTestTestTestTestTestTestTest", "Test", 9999999991L, "test.longfirstname@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testLastNameExceedsMaxLength() {
        User user = new User("Test", "TestTestTestTestTestTestTestTestTestTest", 9999999990L, "test.longlastname@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testEmailExceedsMaxLength() {
        User user = new User("Test", "Test", 9999999989L, "test.veryveryverylongemail@thisisaverylongdomainname.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testSpecialCharactersInFirstName() {
        User user = new User("T#st", "Test", 9999999988L, "test.specialchar@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testSpecialCharactersInLastName() {
        User user = new User("Test", "T@st", 9999999987L, "test.specialcharlast@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testWhitespaceInPhoneNumber() {
        User user = new User("Test", "Test", Long.parseLong("999 999 9996"), "test.whitespacephone@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testNullPhoneNumber() {
        User user = new User("Test", "Test", null, "test.nullphone@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testInvalidEmailDomain() {
        User user = new User("Test", "Test", 9999999985L, "test@.invalid");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testSuccessfulUserCreationWithMinimalFields() {
        User user = new User("Test", "Test", 9999999984L, "minimal@test.com");
        ResponseEntity<String> response = apiService.createUser(user);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}
